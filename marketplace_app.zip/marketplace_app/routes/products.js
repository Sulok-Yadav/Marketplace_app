const express = require("express");
const router = express.Router();
const productController = require("../controllers/productController");

// Get all products if no query and find products by name
router.get("/api/products", productController.findProductsByName);

// Get product by ID
router.get("/api/products/:id", productController.getProductById);

// Add new product
router.post("/api/products", productController.createProduct);

// Update product by ID
router.put("/api/products/:id", productController.updateProduct);

// Remove product by ID
router.delete("/api/products/:id", productController.deleteProduct);

// Remove all products
router.delete("/api/products", productController.removeAllProducts);

module.exports = router;
