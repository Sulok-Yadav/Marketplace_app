var express = require("express");
var router = express.Router();

/* GET home page. */
router.get("/test", function (req, res) {
  res.send({ msg: "Marketplace app is now working" });
});

module.exports = router;
